This game is called Life!

This game is supposed to emphasize the things we choose to focus on in our limited time here on earth,
and where those choices lead us.

To run the game:

Windows: 

Open CMD, and navigate to the directory containing "Life.jar"
type java -jar Life.jar
hit enter
Enjoy!

Mac:

Open terminal, and navigate to the directory containing "Life.jar"
type java -jar Life.jar
hit enter
Enjoy!